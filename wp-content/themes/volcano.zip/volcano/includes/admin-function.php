<?php
require_once('custom_functions/post_type/functions.php');
require_once('custom_functions/feature/functions.php');
require_once('custom_functions/acf/functions.php');
require_once('custom_functions/shortcode/functions.php');