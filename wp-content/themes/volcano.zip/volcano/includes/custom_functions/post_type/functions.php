<?php
require_once('create_custom_post_types.php');
require_once('disable_custom_post_type.php');