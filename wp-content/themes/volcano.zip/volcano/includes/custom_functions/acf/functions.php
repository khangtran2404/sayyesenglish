<?php
require_once('auto_sync_acf.php');