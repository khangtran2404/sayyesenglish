<div class="item">
    <div class="wrapper">
        <a href="<?php the_permalink() ?>">
            <div class="post-thumbnail">
                <?php the_post_thumbnail('product-thumb'); ?>
            </div>
            <div class="post-name">
                <?php the_title() ?>
            </div>
        </a>
    </div>
</div>
